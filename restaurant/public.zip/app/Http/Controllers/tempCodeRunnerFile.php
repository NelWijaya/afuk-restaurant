<?php
'password'  =>  'required|min:8'