<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link href="https://fonts.googleapis.com/css?family=Karla:400,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.materialdesignicons.com/4.8.95/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo asset('css/style.css')?>" type="text/css"> 
</head>

<body>
    <main>
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6 px-0 d-none d-sm-block">
                    <img src="<?php echo asset('images/login.png')?>" alt="login image" class="login-img">
                </div>
                <div class="col-sm-6 login-section-wrapper">
                    <div class="brand-wrapper">
                        <a href="/"><img src="<?php echo asset('images/logo.png')?>" alt="logo" class="logo"></a>
                    </div>
                
                    <div class="login-wrapper my-auto">
                        <?php if($message = Session::get('suksesregist')): ?>
                            <div class="alert alert-info alert-block">
                                <button type="button" class="close" data-dismiss="alert">x</button>
                                <strong><?php echo e($message); ?></strong>
                            </div>
                        <?php endif; ?>
                        <h1 class="login-title">Login Account</h1>
                        <form action="<?php echo e(url('/loginaccount/check')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" name="email" id="inputEmail" class="form-control" placeholder="email@example.com">
                            </div>
                            <div class="form-group mb-4">
                                <label for="password">Password</label>
                                <input type="password" name="password" id="myInput" class="form-control" placeholder="enter your passsword">
                                <input class="mt-3" type="checkbox" onclick="myFunction()">&nbsp;&nbsp;Show Password
                            </div>
                            
                            <?php if(isset(Auth::user()->email)): ?>
                                <script>
                                    window.location = "/";
                                </script>
                            <?php endif; ?>

                            <?php if($message = Session::get('error')): ?>
                                <div class="alert alert-danger alert-block">
                                    <button type="button" class="close" data-dismiss="alert">x</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>

                            <?php if(count($errors) > 0): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                            <button class="btn btn-block login-btn" type="submit">Login</button>
                        </form>
                        <p class="login-wrapper-footer-text"><b>Don't have an account?</b> <a href="/signup" class="text-reset">Register here</a></p>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <script>
    function myFunction() {
    var x = document.getElementById("myInput");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
    }
    </script>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\Ujian\restaurant\resources\views/login.blade.php ENDPATH**/ ?>