<?php if(isset(Auth::user()->email)): ?>
    <strong>Welcome <?php echo e(Auth::user()->email); ?></strong>
    <a href="/logout">Logout</a>
<?php else: ?>
    <script>window.location = "/loginaccount";</script>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Ujian\restaurant\resources\views/posts/sukses.blade.php ENDPATH**/ ?>